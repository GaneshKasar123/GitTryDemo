package com.csi.jdkfeatures;

@FunctionalInterface
interface CorporateData//SAM
{
	void get();
	default void net()
	{
		
	}
	static void pop()
	{
		
	}
	
}
public class FunctionalInterfaceConcept {
	public static void main(String[] args) {

	}
}
